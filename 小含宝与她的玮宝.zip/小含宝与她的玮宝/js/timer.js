var start = new Date(2026, 0, 30).getTime();
var el = document.getElementById('countdown');
var diff = Date.now() - start;
el.innerHTML = Math.floor(diff / 86400000) + ' 天 ' +
  ('0' + Math.floor((diff % 86400000) / 3600000)).slice(-2) + ':' +
  ('0' + Math.floor((diff % 3600000) / 60000)).slice(-2) + ':' +
  ('0' + Math.floor((diff % 60000) / 1000)).slice(-2);