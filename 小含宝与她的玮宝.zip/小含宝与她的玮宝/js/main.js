/**
 * Like_Girl - 情侣纪念网站
 * 公共 JavaScript
 */
 

// ========== Love List 勾选逻辑 ==========
function initLoveList() {
  const items = document.querySelectorAll('.love-item');
  items.forEach(item => {
    item.addEventListener('click', () => {
      item.classList.toggle('checked');
      saveCheckState();
    });
  });
  loadCheckState();
}
 
function saveCheckState() {
  const items = document.querySelectorAll('.love-item');
  const state = [];
  items.forEach((item, i) => {
    state.push(item.classList.contains('checked'));
  });
  localStorage.setItem('love-list-state', JSON.stringify(state));
}
 
function loadCheckState() {
  const saved = localStorage.getItem('love-list-state');
  if (!saved) return;
  const state = JSON.parse(saved);
  const items = document.querySelectorAll('.love-item');
  items.forEach((item, i) => {
    if (state[i]) item.classList.add('checked');
  });
}
 
// ========== 对话框动画 ==========
function initDialogue() {
  const bubbles = document.querySelectorAll('.dialogue-bubble');
  bubbles.forEach((bubble, i) => {
    bubble.style.animationDelay = (i * 0.6) + 's';
  });
}
 
// ========== 初始化 ==========
document.addEventListener('DOMContentLoaded', () => {
  updateCountdown();
  setInterval(updateCountdown, 1000);
  initLoveList();
  initDialogue();
});